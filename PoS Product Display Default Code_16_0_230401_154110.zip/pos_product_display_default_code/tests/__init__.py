# Copyright 2023 FactorLibre - Juan Carlos Bonilla
from . import test_load_params_product
