This module makes Odoo show the internal reference of the product in the Point of Sale.

The reference will appear in the products list, in the orderlines and in the receipt.

example: Desk Organizer -> [FURN_0001] Desk Organizer
