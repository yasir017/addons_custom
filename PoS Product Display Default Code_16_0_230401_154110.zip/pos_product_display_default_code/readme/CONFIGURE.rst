* Go to Point Of Sale / Configuration / Settings
* Check the box 'Display Default Code' in PoS Interface section

.. image:: ../static/description/config.png
   :width: 800 px
