## Module <product_arabic>

#### 21.10.2022
#### Version 16.0.1.0.0
##### ADD
- Initial commit for Arabic product name in POS Receipt

