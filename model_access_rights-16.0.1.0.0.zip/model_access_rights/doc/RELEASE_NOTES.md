## Module <model_access_rights>
#### 8.11.2023
#### Version 16.0.1.0.0
##### ADD
- Initial Commit for Hide Create|Delete|Archive|Export Options - Model Wise
