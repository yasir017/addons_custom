## Module <product_profit_report>

#### 09.10.2023
#### Version 16.0.1.0.0
##### ADD
- Initial commit for Product Profit Report

#### 03.05.2024
#### Version 16.0.1.0.0
##### Bug Fix
- Bug fix- Multi Currency
