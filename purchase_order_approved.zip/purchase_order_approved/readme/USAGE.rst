To use this module, you need to:

#. Go to a Request for Quotation.
#. Click *Confirm Order*. The state is now *Approved* (if no order approval
   is not set).
#. To move forward to the state *Purchase Order* and release the creation
   of the deliveries, click on *Convert to Purchase Order*.
