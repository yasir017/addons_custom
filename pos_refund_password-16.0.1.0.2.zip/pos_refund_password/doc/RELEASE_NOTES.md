## Module <pos_refund_password>

#### 30.12.2022
#### Version 16.0.1.0.0
#### ADD
- Initial commit for pos_refund_password odoo

#### 28.03.2023
#### Version 16.0.1.0.1
#### FIX
- Fixed the undeclared body 

#### 06.09.2023
#### Version 16.0.1.0.2
#### FIX
- Fixed the refund password issue

#### 28.03.2024
#### Version 16.0.1.0.3
#### FIX
- Fixed the access right issue.