## Module <product_multi_uom_pos>

#### 18.10.2023
#### Version 16.0.1.0.0
#### ADD
- Initial commit for POS Product Multiple UOM

#### 20.02.2024
#### Version 16.0.1.0.0
#### FIX
- Fixed UOM saving issue when POS tables switched.