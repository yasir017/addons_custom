* OpenERP S.A.
* Ignacio Ibeas <ignacio@acysos.com>
* Pedro M. Baeza <pedro.baeza@tecnativa.com>
* Jonathan Nemry <jonathan.nemry@acsone.eu>
* Sylvain LE GAL (https://twitter.com/legalsylvain)
* Stefan Rijnhart <stefan@opener.amsterdam>
* `Tecnativa <https://www.tecnativa.com>`_:

  * Pedro M. Baeza
  * Vicent Cubells <vicent.cubells@tecnativa.com>

* Sudhir Arya <sudhir@erpharbor.com>
* Lorenzo Battistini <https://github.com/eLBati>
* Luisa Miguéns <luisa.miguens@solvos.es>
* Vishnu Vanneri <vanneri.odoodev@gmail.com>
* Moaad Bourhim <moaad.bourhim@gmail.com>
